using System;

public class HeroScreen : MainScreen
{

}
