using UnityEngine;

public class ExploreScrollLimit : ScrollLimit
{

}
