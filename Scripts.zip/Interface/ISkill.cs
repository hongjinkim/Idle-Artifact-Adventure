
public interface ISkill
{
    void UseSkill()
    {}
}
