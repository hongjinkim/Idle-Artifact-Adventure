public class Goblin : Character
{

}
