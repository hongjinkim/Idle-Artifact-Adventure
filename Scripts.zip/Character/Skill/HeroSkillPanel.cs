using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class HeroSkillPanel : MonoBehaviour
{
    public List<Button> skillButtons;
    public List<TextMeshProUGUI> skillLevelTexts;
    public List<Image> skillIconImages;
    public List<Sprite> skillIcons;
    private HeroInfo currentHeroInfo;

    
}
