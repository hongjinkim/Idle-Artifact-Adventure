public class DoubleStrike : ISkill
{

}
